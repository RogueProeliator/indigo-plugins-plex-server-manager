# Plex Media Server Manager Plugin - Python 3 Conversion

## Version 3.0.0

This is a Python 3 conversion of the Plex Media Server Manager plugin for Indigo 2025.1.

### Changes Made

#### 1. API Version Update
- Updated `ServerApiVersion` from `2.0` to `3.0` in `Info.plist` to support Indigo 2025.1
- Updated plugin version from `2.3.5` to `3.0.0`

#### 2. Import Statements
Updated all Python 2 imports to Python 3 equivalents:

- `httplib` → `http.client`
- `urllib2` → `urllib.request`
- `urllib` → `urllib.parse`
- `urlparse` → `urllib.parse`
- `Queue` → `queue`
- `StringIO` → `io.BytesIO` / `io.StringIO`
- `ConfigParser` → `configparser`

#### 3. Unicode Handling (RPFrameworkUtils.py)
Rewrote `to_unicode()` and `to_str()` functions for Python 3:
- In Python 3, `str` is unicode by default
- Removed references to `basestring` and `unicode()` function
- Updated to handle `bytes` type properly

#### 4. String and Dictionary Methods
- Replaced `.iteritems()` with `.items()` in dictionary iterations
- Replaced `.has_key()` with `in` operator
- Removed `basestring` type checks, replaced with `str`

#### 5. Print Statements
- Converted all `print` statements to `print()` function calls in debug code

#### 6. Removed Direct unicode() Calls
- Replaced direct `unicode()` calls with `RPFramework.RPFrameworkUtils.to_unicode()` for consistency

### Files Modified

#### Core Plugin Files:
- `Contents/Info.plist` - Updated API version and plugin version
- `Contents/Server Plugin/plugin.py` - Fixed unicode() call
- `Contents/Server Plugin/plexMediaServerDevices.py` - Fixed imports and .iteritems()
- `Contents/Server Plugin/plexMediaContainer.py` - Fixed imports

#### RPFramework Files:
- `RPFramework/RPFrameworkUtils.py` - Rewrote unicode handling for Python 3
- `RPFramework/RPFrameworkCommand.py` - Replaced basestring with str
- `RPFramework/RPFrameworkRESTfulDevice.py` - Updated imports
- `RPFramework/RPFrameworkTelnetDevice.py` - Updated imports
- `RPFramework/RPFrameworkNetworkingUPnP.py` - Updated imports and StringIO usage
- `RPFramework/RPFrameworkUpdater.py` - Updated imports
- `RPFramework/dataAccess/bpgsql.py` - Updated print statements and has_key()

### Compatibility

This plugin is compatible with:
- **Indigo Version**: 2025.1 and later
- **Python Version**: Python 3.10+
- **macOS Version**: As supported by Indigo 2025.1

### Installation

1. Quit Indigo if it's running
2. Double-click the `.indigoPlugin` file to install
3. Restart Indigo
4. The plugin should now work with Python 3

### Testing Recommendations

After installation, please test:
1. Server connectivity and authentication
2. Client detection and tracking
3. Playback control commands
4. Artwork download functionality
5. Session status updates

### Original Plugin Information

- **Original Author**: RogueProeliator (adam.d.ashe@gmail.com)
- **Original Repository**: https://github.com/RogueProeliator/IndigoPlugins-Plex-Server-Manager-Plugin
- **License**: MIT License (see LICENSE.txt in the original repository)

### Python 3 Conversion

- **Conversion Date**: October 29, 2025
- **Converted for**: Indigo 2025.1 compatibility

### Notes

- All core functionality should be preserved
- The plugin maintains backward compatibility with existing device configurations
- Some minor edge cases in the RPFramework library may require additional testing
